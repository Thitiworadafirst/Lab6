package com.example.lab7dialog

data class Student (val id:String,val name:String,val age:Int){
}